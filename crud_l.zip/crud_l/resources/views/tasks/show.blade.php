@extends('layout.layout')

@section('content')
            <h4>Showing Data {{ $task->title }}</h4>

    <div class="jumbotron text-center">
        <p>
            <strong>Task Title:</strong> {{ $task->title }}<br>
            <strong>Description:</strong> {{ $task->description }}
        </p>
    </div>
@endsection
