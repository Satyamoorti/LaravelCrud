<?php $__env->startSection('content'); ?>
            <h4>Showing Data <?php echo e($task->title); ?></h4>

    <div class="jumbotron text-center">
        <p>
            <strong>Task Title:</strong> <?php echo e($task->title); ?><br>
            <strong>Description:</strong> <?php echo e($task->description); ?>

        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud_l\resources\views/tasks/show.blade.php ENDPATH**/ ?>